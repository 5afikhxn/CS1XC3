/**
 * @file main.c
 * @author Safi Khan
 * @brief 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */

// We include the course.h header file as it 
// contains the necesarry structures that are 
// needed for this file to run. We also note that
// the student.h header file is included in the 
// course.h header file as it is also needed for
// this program to run.  
#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/**
 * @brief This program uses previous funtions
 *        used in both student.c and course.c
 *        to print overall results. 
 * 
 * @return int Return 0 to run the code. 
 */

// This function creates a course structure with the 
// name MATH101. It will enroll up to 20 students in 
// the course, each with 8 random grades. Then the structure student 
// is created with the name student. Then it will take the student
// with the highest grade and print the student. 
// Then it will print an array of the 
// students that are passing MATH101. 
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));
  strcpy(MATH101->name, "Basics of Mathematics");
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));
  
  print_course(MATH101);

  Student *student;
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;
  Student *passing_students = passing(MATH101, &total_passing);
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]);
  
  return 0;
}