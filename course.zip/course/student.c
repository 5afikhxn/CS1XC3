/**
 * @file student.c
 * @author Safi Khan
 * @brief This program will add grades to each of
 *        the students grade array, returns the 
 *        students' overall average, and generate
 *        an array of students with random first 
 *        and last names along with a random grade.  
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief This function adds a grade to each students
 *        grade array. The grade will be in the form
 *        of double. 
 * 
 * @param student Includes the structure student.
 * @param grade The grades that are appended in the array whenever
 *        a course is added. 
 */

// This function allocates memory to ensure there is 
// enough space for new courses and grades to be added.
// The grade of the new course is appended to the end of 
// the array. 
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief This funtion returns a students
 *        overall average. 
 * 
 * @param student Includes the structure student. 
 * @return double Returns average of student in type double. 
 */

double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  return total / ((double) student->num_grades);
}

/**
 * @brief This funtion prints the students
 *        name, ID, Grades, and average to
 *        terminal when the program is run.  
 * 
 * @param student Includes the structure student. 
 */

void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief This function returns a new student 
 *        structure with a first and last name. 
 *        It also will assign each student random
 *        grades to their grade list. 
 * 
 * @param grades The random grades that are assigned to each new student. 
 * @return Student* 
 */

Student* generate_random_student(int grades)
{
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student));

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}