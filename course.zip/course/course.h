/**
 * @file course.h
 * @author Safi Khan
 * @brief This is the header file which is created for 
 *        the file course.c. It contains the necesarry
 *        functions and structures needed for course.c 
 *        to run when we import this header file. 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

// We include student.h as well because it contains 
// the necesarry functions and structures needed for
// course.h which is needed by course.c.
#include "student.h"
#include <stdbool.h>

/**
 * @brief This structure is called course. 
 *        It is a structure that is necesarry
 *        for running all the files which include
 *        the structure course. 
 */

typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

/**
 * @brief These are functions created and defined 
 *        in our header file for course.c. They 
 *        will be used so that the program course.c
 *        can run without any errors. The structure
 *        student is included because it is necessary
 *        for the program course.c to run without errors.  
 * 
 * @param course Includes the previously mentioned structure course.
 * @param student Includes the previously mentioned structure student. 
 */

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


