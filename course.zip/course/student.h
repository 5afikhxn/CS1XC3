/**
 * @file student.h
 * @author Safi Khan
 * @brief This is the header file which is created for 
 *        the file student.c. It contains the necesarry
 *        functions and structures needed for student.c 
 *        to run when we import this header file. This 
 *        file is also needed for the course.h header 
 *        file. 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief This structure is called student. 
 *        It is a structure that is necesarry
 *        for running all the files which include
 *        the structure course.
 * 
 */

typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

/**
 * @brief These are functions created and defined 
 *        in our header file for student.c. They 
 *        will be used so that the program student.c
 *        can run without any errors.
 * 
 * @param student Includes the previously mentioned structure called student. 
 * @param grade Grade will be in type double. 
 */

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
