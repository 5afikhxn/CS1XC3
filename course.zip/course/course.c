/**
 * @file course.c
 * @author Safi Khan
 * @brief This program is for students to be enrolled 
 *        into courses, then print the student information
 *        with their courses, and determines which students
 *        are passing, and which students have the highest 
 *        grade. 
 * @version 0.1
 * @date 2022-04-11
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/**
 * @brief This functions is how students get enrolled
 *        into courses. 
 * 
 * @param course Includes the structure named course.
 * @param student Includes the sturcture named student.
 */

// In this function, we are allocating memory for the student
// structure and appending the new student to the array 
// course[students]. Everytime we need to make more space in
// the array, realloc will ensure we have enough space. 
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief This function takes user input for the course
 *        name, code, and the total number of students in
 *        said course and then prints the result. 
 * 
 * @param course Includes the structure course.
 */

void print_course(Course* course)
{
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

// This function determines who the student in the course
// is with the highest average. In the case there are no
// students in the course, we return null. 
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL;
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief This function will return an array of all the 
 *        students in the course that have a passing grade.
 * 
 * @param course Includes the structure course. 
 * @param total_passing The number of students passing the course. 
 * @return Student* 
 */

// The function below allocates memory using calloc
// for students that get a passing grade. In the case
// where no students in the course are passing, we 
// simply return null. 
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  passing = calloc(count, sizeof(Student));

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}